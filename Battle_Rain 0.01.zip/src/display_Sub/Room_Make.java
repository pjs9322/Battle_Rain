package display_Sub;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import control.Control;

public class Room_Make extends Sub_Frame {
	private static final long serialVersionUID = 1L;

	private JLabel roomName = new JLabel("�� ����");
	private JTextField roomText = new JTextField(15);
	
	private ButtonGroup group = new ButtonGroup();
	private JRadioButton team = new JRadioButton("����");
	private JRadioButton single = new JRadioButton("����");
	
	private JButton ok_Button = new JButton("����");
	private JButton cancel_Button = new JButton("���");
	
	public Room_Make(Control control) {
		super(control, 250, 130);
		
		this.setTitle("�� �����");

		this.panel_NORTH.add(roomName);
		this.panel_NORTH.add(roomText);
		this.panel_NORTH.add(team);
		this.panel_NORTH.add(single);

		this.team.doClick();
		this.group.add(team);
		this.group.add(single);

		this.panel_SOUTH.add(ok_Button);
		this.panel_SOUTH.add(cancel_Button);

		this.ok_Button.setText("����");
		this.ok_Button.addActionListener(actionListener);
		this.ok_Button.setActionCommand("Make");
		
		this.cancel_Button.setText("���");
		this.cancel_Button.addActionListener(actionListener);
		this.cancel_Button.setActionCommand("Cancel");
	}

	public void Make() {
		String alart = this.control.Room_Make(this.roomText.getText());
		if (alart != null) {
			JOptionPane.showMessageDialog(this, alart, "���", 0);
		} else {
			this.dispose();
		}
	}
	
	public void Cancel() {
		this.dispose();
	}
}
